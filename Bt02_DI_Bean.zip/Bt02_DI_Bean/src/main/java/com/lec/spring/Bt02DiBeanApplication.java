package com.lec.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bt02DiBeanApplication {

	public static void main(String[] args) {
		SpringApplication.run(Bt02DiBeanApplication.class, args);
	}

}
